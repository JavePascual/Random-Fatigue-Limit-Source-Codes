source("allfcns.R")
.First()

# Standard Random Fatigue Limit Model
# Reference Pascual (2003).  A Standardized Form of the Random
#    Fatigue-Limit Model, COMMUNICATIONS IN STATISTICS, Simulation and 
#    Computation Vol. 32, No. 4, pp. 1209-1227, 2003

# ydist = distribution for log lifetime (1=sev,2=normal)
# fldist = distribution for log(fatigue limit) (1=sev,2=normal)
# xi=standardized stress
# beta1=standardized slope
# z=standardized log life
# sdgamma=scale parameter of log(fatigue limit)

rfl0cdf(ydist, fldist, z, xi, beta1, sdgamma) # std cdf
rfl0pdf(ydist, fldist, z, xi, beta1, sdgamma) # std pdf
rfl0quan(ydist, fldist, xi, alpha, beta1, sdgamma, bd1 = -30, bd2 = 30) 
  #std quantile


# How to create RFL data sets in R.
# Have data in a text file with 3 columns of data (numbers only).
#   column 1 = all the stress levels (untransformed)
#   column 2 = all the fatigue lives (untransformed)
#   column 3 = censoring codes (1=failure, 2=runout)
# Don't include column labels.

# The command below is for concrete data I've included in the zipped 
# files. 

concrete.d=rflm.read.data(data.file="concrete.txt",dat.mat=NULL,title="Concrete Data",xlab="stress",units="1000 cycles")

# Get ML estimates of RFL model parameters
# dist = 1 for Weibull, 2 for lognormal
# ydist= life distn, fldist=fatigue limit distn

concrete.out=get.rfl0.mle(concrete.d,ydist=2,fldist=2)
panel22.out=get.rfl0.mle(panel.d,ydist=2,fldist=2)
inconel11.out=get.rfl0.mle(inconel.d,ydist=1,fldist=1)

#plot MLEs of quantiles

rfl0.mle.plot(panel22.out)
rfl0.mle.plot(inconel11.out)

rev.rfl0.mle.plot(panel22.out,quan.vec=c(.10,.90),pts=50,adjust=.05)
rev.rfl0.mle.plot(inconel11.out,quan.vec=c(.01,.25,.75,.99),pts=50,adjust=.05)

# Find likelihood ratio confidence interval for log(sigma.gamma).  
# profile.on.list=5 means that log(sigma.gamma) is the 5th parameter. 
# 2*size+1 is the number of points in the profile plot.  
# range.list gives the range of values over which to compute the profile.

one.dim(panel22.out,profile.on.list = 5,size=5,range.list=list(log(c(.015,.055))))

#
# beta0 was transformed as beta0 + beta1 * mean(log(stresses))
# beta1 was not transformed.  

one.dim(panel22.out,profile.on.list = 2,size=5,range.list=list(c(-8,-3.5)))

# sigma and sigma.gamma were transformed as log(sigma), log(sigma.gamma).
# Logarithm was applied to sigma and sigma.gamma.
# mu.gamma was transformed as - (mu.gamma - mean(low3rd))/sigma.gamma where
#    low3rd=log(sort(stress)[1:as.integer(length(stress)/3)]) = roughly the logs of the lowest 1/3 
#                                                               of all stresses
# Confidence intervals obtained are for the transformed parameters as defined above.

#------------
# The commands below generate a relative (profile) likelihood plot to obtain 
# likelihood-ratio based
# confidence intervals for the alpha quantile of lifetime at a given stress level. 
# Plots generated are like Figures 2 and 11 in the RFL paper.
# 

draw.profile.quan.1(output=panel22.out,ydist=2,fldist=2,stress=260,alpha=.01,quan.range=c(5500,15000),size=6,one.sided.level=.99)
draw.profile.quan.1(output=panel22.out,ydist=2,fldist=2,stress=260,alpha=.05,quan.range=c(8500,24000),size=9,one.sided.level=.975)

# quan.range is the range of evaluation.  For a lower one-sided bound I recommend that
# the 2nd value be the maximum likelihood estimate of the quantile (which is given by 
# the first value in h.theta.hat - see sample output below).  
#
# 2*size is the number of points plotted.  The higher, the more accurate the estimate
# of the confidence bounds.

# one.sided.level is the confidence level for the single confidence bound.
# The plot generated indicates the confidence level for 2 sided intervals, i.e.
#   (2-sided confidence) = 1-(1-one.sided.level)*2
 
# 14274.5552 is the ML estimate of the .05 quantile at stress=260 for the laminate
# panel data with loglife~normal (ydist) and logfatigue-limit~normal (fldist)
# The program goes through about 2*size calculations before it generates a relative
# likelihood ratio plot (like Figure 2 in the paper).  The confidence bounds are
# obtained by interpolating between 2 plotted points.

# The program creates a file "struct6" which contains the plotting points.  Issue this 
# command to recreate the plot:

profile.plot(struct6,confidence.level=.99)

# confidence.level is for 2-sided intervals.  .99 yields 
# 1-(1-.99)/2=.995 for one-sided.
