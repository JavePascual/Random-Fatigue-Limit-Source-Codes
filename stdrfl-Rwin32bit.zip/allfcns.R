rfl0.loglike.fl=function(theta)
{
#
# negative log likelihood of the location-scale model
#
# pick up the data which was previously assigned to frame 1
	data.d <- get("mle.data", pos = 1)
	fixed.fl.vals <- data.d$fixed.fl.vals
	ydist <- data.d$ydist
	fldist <- data.d$fldist
	xmat <- data.d$xmat
	mean.lx <- mean(log(xmat))
	beta1 <- theta[2]
	beta0 <- theta[1] - beta1 * mean.lx
	sigma <- exp(theta[3])
	sdgamma <- fixed.fl.vals[2]
	mugamma <- fixed.fl.vals[1]
	beta0.r <- beta0 + beta1 * mugamma
	beta1.r <- beta1/sigma
	x <- (log(xmat) - mugamma)/sdgamma
	y <- data.d$log.y
	z <- (y - beta0.r)/sigma
	ccodes <- data.d$censor.codes	#compute and return minus log likelihood
#
	censored <- ccodes == 2
	failed <- ccodes == 1
	runout <- 0
	if(any(censored)) {
		z.cens <- z[censored]
		x.cens <- x[censored]
		cdf.val <- rfl0cdf(ydist, fldist, z.cens, x.cens, beta1.r, 
			sdgamma)
		if(any(is.na(cdf.val)) | any(cdf.val >= 1))
			return(10000000000)
		else runout <- sum(log(1 - cdf.val))
	}
	z.fail <- z[failed]
	x.fail <- x[failed]
	pdf.val <- rfl0pdf(ydist, fldist, z.fail, x.fail, beta1.r, sdgamma)/
		sigma
	if(any(pdf.val <= 0) | any(is.na(pdf.val))) {
#    print(z.fail)
#    browser()
#    stop()
		return(10000000000)
	}
	else failure <- sum(log(pdf.val))
	log.like <- runout + failure
	if(dump > 2) {
		print(log.like)
		if(dump > 3)
			print(paste(beta0, beta1, sigma))
	}
	return(-(log.like))
}

get.stdrfl.start.fl=function(data, fixed.fl.vals,n)
{
	mugamma0 <- fixed.fl.vals[1]
	xvals <- data$xmat
	yvals <- data$log.y[xvals > exp(mugamma0)]
	xvals <- xvals[xvals > exp(mugamma0)]
	loglikes <- 1:n
	beta0 <- 1:n
	beta1 <- 1:n
	lsigma <- -0.69999999999999996
	sdgamma <- fixed.fl.vals[2]
	lsdgamma <- log(sdgamma)
	low3rd <- log(sort(xvals)[1:as.integer(length(xvals)/3)])
	mugamma <-  - (mugamma0 - mean(low3rd))/sdgamma
	lin.coefs <- lsfit(log(xvals - exp(mugamma0)), yvals)$coef
	ssize <- length(xvals)
	beta1 <- lin.coefs[2]
	beta0 <- lin.coefs[1] + beta1 * mean(log(xvals))
	theta.start <- c(beta0, beta1, lsigma)	#  print("starting values")
#  print(theta.start)
	return(theta.start)
}

get.stdrfl.mle.fl=function(data = inconel7.d, theta.start = NULL, fixed.fl.vals = NULL, ydist = 2, fldist = 2, npts = 5, dump = F)
{
# dist=1 weibull
# dist=2 lognormal
# dist=3 loglogistic
	data$ydist <- ydist
	data$fldist <- fldist
	data$fixed.fl.vals <- fixed.fl.vals
	xmat <- data$xmat
	mean.lx <- mean(log(xmat))
	assign("dump", dump, pos = 1)	#	
#set up sample size and model parameters
#for the regression model
# 
	param.names <- c("beta0", "beta1", "sigma")
	t.param.names <- c("beta0*", "beta1", "lsigma")
	if(is.null(theta.start)) {
		theta.start <- get.stdrfl.start.fl(data, fixed.fl.vals,
                                                   npts)
	}
	gmle.out <- gmle(log.like = rfl0.loglike.fl, mle.data = data, 
		theta.start = theta.start, model = NULL,
                         special.stuff = NULL, 
                         t.param.names = t.param.names, dump = dump)
	theta.hat <- gmle.out$est.out$par
	beta1 <- theta.hat[2]
	beta0 <- theta.hat[1] - beta1 * mean.lx
	sigma <- exp(theta.hat[3])
        parameters <- list(beta0 = beta0, beta1 = beta1, sigma = sigma,
                           fixed.fl.vals=fixed.fl.vals)
        gmle.out$parameters <- parameters
        print(parameters)
        pause()
        return(gmle.out)
}

.First=function()
{
	dyn.load("stdrfl.dll")
}

get.rfl0.mle=function(data = inconel.d, theta.start = NULL, ydist = 2, fldist = 2, npts = 
           5, dump = F)
{
                                        # dist=1 weibull
                                        # dist=2 lognormal
                                        # dist=3 loglogistic
  data$ydist <- ydist
  data$fldist <- fldist
  xmat <- data$xmat
  mean.lx <- mean(log(xmat))
  assign("dump", dump, pos=1)	#	
                                        #set up sample size and model parameters
                                        #for the regression model
                                        # 
  param.names <- c("beta0", "beta1", "sigma", "mugamma", "sdgamma")
  t.param.names <- c("beta0*", "beta1", "lsigma", "mugamma*", "lsdgamma")
  model <- NULL
  if(is.null(theta.start)) {
    theta.start <- get.rfl0.start(data, ydist, fldist, npts)	
                                        #    print(theta.start)
  }
  gmle.out <- gmle(log.like = rfl0.loglike, mle.data = data, theta.start
                   = theta.start, model = model, special.stuff = NULL, 
                   t.param.names = t.param.names, dump = dump)
  theta.hat <- gmle.out$est.out$par
  beta1 <- theta.hat[2]
  beta0 <- theta.hat[1] - beta1 * mean.lx
  sigma <- exp(theta.hat[3])
  sdgamma <- exp(theta.hat[5])
  low3rd <- log(sort(xmat)[1:as.integer(length(xmat)/3)])
  x0 <- mean(low3rd)
  mugamma <- x0 - sdgamma * theta.hat[4]
  parameters <- list(beta0 = beta0, beta1 = beta1, sigma = sigma, mugamma
                     = mugamma, sdgamma = sdgamma)
  gmle.out$parameters <- parameters
  print(parameters)
  pause()
  return(gmle.out)
}

get.rfl0.start=function(data, ydist, fldist, n)
{
  xvals <- data$xmat
  yvals <- data$log.y
  minx <- min(xvals)
  xbound <- 0.95 * minx
  mugamma <- seq(log(minx/n), log(xbound), length = n)
  loglikes <- 1:n
  beta0 <- 1:n
  beta1 <- 1:n
  lsigma <- log(.25)
  lsdgamma <- log(.25)
  for(i in 1:n) {
    lin.coefs <- lsfit(log(xvals - exp(mugamma[i])), yvals)$coef
    ssize <- length(xvals)
    beta1[i] <- lin.coefs[2]
    beta0[i] <- lin.coefs[1] + beta1[i] * mean(log(xvals))
    low3rd <- log(sort(xvals)[1:as.integer(length(xvals)/3)])
    mugamma[i] <-  - (mugamma[i] - mean(low3rd))/exp(lsdgamma)
    loglikes[i] <-  - my.loglike0(c(beta0[i], beta1[i], lsigma, 
                                    mugamma[i], lsdgamma), data, ydist, fldist)
    print(loglikes[i])
  }
  which <- rank(loglikes) == n
  theta.start <- c(beta0[which], beta1[which], lsigma, mugamma[which], 
                   lsdgamma)
  print("starting values")
        print(theta.start)
        return(theta.start)
}

rfl0.loglike=function(theta){
                                        #
                                        # negative log likelihood of the location-scale model
                                        #
                                        # pick up the data which was previously assigned to frame 1
  data.d <- get("mle.data",pos=1.)
  ydist <- data.d$ydist
  fldist <- data.d$fldist
  xmat <- data.d$xmat
  mean.lx <- mean(log(xmat))
  beta1 <- theta[2]
  beta0 <- theta[1] - beta1 * mean.lx
  if(theta[3]< (-20))
    return(1000000)
  else{
    sigma <- exp(theta[3])
    sdgamma <- exp(theta[5])
    low3rd <- log(sort(xmat)[1:as.integer(length(xmat)/3)])
    mugamma <- mean(low3rd) - sdgamma * theta[4]
    beta0.r <- beta0 + beta1 * mugamma
    beta1.r <- beta1/sigma
    x <- (log(xmat) - mugamma)/sdgamma
    y <- data.d$log.y
    z <- (y - beta0.r)/sigma
    ccodes <- data.d$censor.codes	#compute and return minus log likelihood
                                        #
    censored <- ccodes == 2
    failed <- ccodes == 1
    runout <- 0
    if(any(censored)) {
      z.cens <- z[censored]
      x.cens <- x[censored]
      cdf.val <- rfl0cdf(ydist, fldist, z.cens, x.cens, beta1.r, 
                         sdgamma)
      if(any(is.na(cdf.val)) | any(cdf.val >= 1))
        return(10000000000)
      else runout <- sum(log(1 - cdf.val))
    }
    z.fail <- z[failed]
    x.fail <- x[failed]
    pdf.val <- rfl0pdf(ydist, fldist, z.fail, x.fail, beta1.r, sdgamma)/
      sigma
    if(any(pdf.val <= 0) | any(is.na(pdf.val))) {
                                        #    print(z.fail)
                                        #    browser()
                                        #    stop()
      return(10000000000)
    }
    else{
      failure <- sum(log(pdf.val))
      log.like <- runout + failure
      if(dump > 2) 
        print(log.like)
      if(dump > 3)
        print(paste(beta0, beta1, sigma, mugamma, sdgamma))
      return(-(log.like))
    }
  }
}

my.loglike0=function(theta, data.d, ydist, fldist)
{
  xmat <- data.d$xmat
  mean.lx <- mean(log(xmat))
  beta1 <- theta[2]
  beta0 <- theta[1] - beta1 * mean.lx
  sigma <- exp(theta[3])
  sdgamma <- exp(theta[5])
  low3rd <- log(sort(xmat)[1:as.integer(length(xmat)/3)])
  mugamma <- mean(low3rd) - sdgamma * theta[4]
  beta0.r <- beta0 + beta1 * mugamma
  beta1.r <- beta1/sigma
  x <- log(xmat) - mugamma
  y <- data.d$log.y
  z <- (y - beta0.r)/sigma
  ccodes <- data.d$censor.codes
  censored <- ccodes == 2
  failed <- ccodes == 1
  runout <- 0
  if(any(censored)) {
    z.cens <- z[censored]
    x.cens <- x[censored]
    cdf.val <- rfl0cdf(ydist, fldist, z.cens, x.cens, beta1.r, 
                       sdgamma)
    if(any(is.na(cdf.val)) | any(cdf.val >= 1))
      return(10000000000)
    else runout <- sum(log(1 - cdf.val))
  }
  z.fail <- z[failed]
  x.fail <- x[failed]
  pdf.val <- rfl0pdf(ydist, fldist, z.fail, x.fail, beta1.r, sdgamma)/
    sigma
  if(any(pdf.val <= 0) | any(is.na(pdf.val))) {
    return(10000000000)
  }
  else failure <- sum(log(pdf.val))
  log.like <- runout + failure
  return(-(log.like))
}

rfl0pdf=function(ydist, fldist, z, xi, beta1, sdgamma)
{
        max.length <- max(length(ydist), length(fldist), length(beta1), length(
                sdgamma), length(xi), length(z))
#        if(any(is.na(c(z,xi,beta1,sdgamma)))) return(rep(0,max.length))
#        if(any(abs(c(z,xi,beta1,sdgamma)==Inf))) return(rep(0,max.length))
        ydist <- expand.vec(ydist, max.length)
        fldist <- expand.vec(fldist, max.length)
        beta1 <- expand.vec(beta1, max.length)
        sdgamma <- expand.vec(sdgamma, max.length)
        xi <- expand.vec(xi, max.length)
        z <- expand.vec(z, max.length)
        zout <- .Fortran("srfl0pdf",
                as.integer(ydist),
                as.integer(fldist),
                as.double(z),
                as.double(xi),
                as.double(beta1),
                as.double(sdgamma),
                as.integer(max.length),
                answer = double(max.length),
                ieri = integer(max.length),
                ier1 = integer(max.length),
                ier2 = integer(max.length))
        return(zout$answer)
}

rfl0cdf=function(ydist, fldist, z, xi, beta1, sdgamma)
{
  max.length <- max(length(ydist), length(fldist), length(beta1), 
    length(sdgamma), length(xi), length(z))
#  if(any(is.na(c(z,xi,beta1,sdgamma)))) return(rep(0,max.length))
#  if(any(abs(c(z,xi,beta1,sdgamma)==Inf))) return(rep(0,max.length))
  ydist <- expand.vec(ydist, max.length)
  fldist <- expand.vec(fldist, max.length)
  beta1 <- expand.vec(beta1, max.length)
  sdgamma <- expand.vec(sdgamma, max.length)
  xi <- expand.vec(xi, max.length)
  z <- expand.vec(z, max.length)
  zout <- .Fortran("srfl0cdf",
                   as.integer(ydist),
                   as.integer(fldist),
                   as.double(z),
                   as.double(xi),
                   as.double(beta1),
                   as.double(sdgamma),
                   as.integer(max.length),
                   answer = double(max.length),
                   ieri = integer(max.length),
                   iers = integer(max.length))
  return(zout$answer)
}

print.gmle=function(gmle.out, full.output = T, conf.level = DefaultConfidenceLevel/100, 
           digits = 4, print.vcv = F, add.title = NULL, quote = T, prefix = "")
{
  old.options <- options(digits = digits)
  on.exit(options(old.options))
  cat(paste("\n\n", gmle.out$mle.data$title, add.title, "\n"))
  cat(paste("\nResponse units: ", gmle.out$mle.data$time.units, "\n", sep
            = ""))
  cat("Maximum likelihood estimation results:\n \n")
  if(gmle.out$est.out$converged)
    result <- " Converged;"
  else result <- " Did not converge;"
  if(full.output)
    cat(result, gmle.out$est.out$conv.type, " \n \n")
  cat("\nLog likelihood at maximum point:", format(gmle.out$max.log.like),
      "\n \n") 
                                        # print(list(mle.results = gmle.out$est.out, max.log.like = gmle.out$
                                        #  max.log.like)) #
                                        #hessian and variance covariance matrix
                                        #
  if(full.output || is.null(gmle.out$origparam)) {
    cat(" Transformed parameter ML estimates:\n")
    print(gmle.out$t.param)
    cat("\n Transformed parameter MLE hessian matrix:\n")
    print(gmle.out$hess)
    cat("\n Transformed parameter MLE variance-covariance matrix\n"
        )
    print(gmle.out$t.vcv)
    cat("\n Transformed parameters  MLE correlation matrix\n")
    param.corr <- ccor(gmle.out$t.vcv)
    dimnames(param.corr) <- dimnames(gmle.out$t.vcv)
    print(param.corr)
    cat("\n Eigen structure of the transformed parameters  MLE correlation matrix:\n"
        )
    print(eigen(param.corr))
    cat("Standard errors for transformed parameter MLEs:\n")
    std.errors <- sqrt(diag(gmle.out$t.vcv))
    names(std.errors) <- dimnames(gmle.out$t.vcv)[[1]]
    print(std.errors)
  }
  if(!is.null(gmle.out$origparam)) {
    cat("\n Original parameter MLEs:\n")
    print(gmle.out$origparam)
  }
  if(!is.null(gmle.out$origparamvcv)) {
    cat("\n Standard errors for original parameter MLEs:\n")
    se.orig <- sqrt(diag(gmle.out$origparamvcv))
    names(se.orig) <- dimnames(gmle.out$origparamvcv)[[1]]
    print(se.orig)
    if(full.output) {
      cat("\n Original parameter MLE variance-covariance matrix\n"
          )
      print(gmle.out$origparamvcv)
      cat("\n Original parameter MLE correlation matrix\n")
      param.corr <- ccor(gmle.out$origparamvcv)
      dimnames(param.corr) <- dimnames(gmle.out$origparamvcv)
      print(param.corr)
      cat("\n Eigen structure of the original parameter MLE correlation matrix:\n"
          )
      eigen.out <- eigen(param.corr)
      print(eigen.out)
      if(any(eigen.out$values < 0)) {

        print("Negative correlation matrix eigenvalues"
              )
        warning(
                "Negative correlation matrix eigenvalues")
      }
    }
  }
  if(!is.null(gmle.out$thetainterp)) {
    cat("\n  Interpretation parameter MLEs \n")
    print(gmle.out$thetainterp)
  }
  invisible()
}

gmle=function(log.like, mle.data, theta.start, model = NULL, f.origparam = function(
                                                            theta, model)
           {
             return(theta)
           }
           , f.tranparam = function(theta, model)
           {
             return(theta)
           }
           , em.alg = NULL, special.stuff = NULL, dump = 1, func.call = match.call(), 
           t.param.names = paste("Tparam", seq(1:length(theta.start)), sep = ""), 
           orig.param.names = paste("Oparam", seq(1:length(theta.start)), sep = ""
             ), max.fcal = 900, max.iter = 200, rfc.tol = 1.0000000000000001e-15, 
           digits = 5, ...)
{
                                        #
                                        #general maximum likelihood
                                        #
                                        #the likelihood function should be in the form of a good parameterization
                                        #data and parameter transformation info is assumed to be on the database
                                        #
  iter.count <<- 0
  options(digits = digits)
  y <- as.matrix(mle.data$y)
  if(is.null(mle.data$case.weights))
    mle.data$case.weights <- rep(1, nrow(y))
  if(is.null(mle.data$censor.codes)) mle.data$censor.codes <- rep(1, nrow(
                                                                          y)) 
                                        #store the likelihood def and data on frame 1 so that they can
                                        #be accessed below
                                        #
  model$f.tranparam <- f.tranparam
  model$f.origparam <- f.origparam
  model$t.param.names <- t.param.names
  model$orig.param.names <- orig.param.names
  assign("log.like", log.like,pos=1)
  assign("model", model,pos=1) # browser()
  if(!exists("dump", frame = 1))
    assign("dump", dump)
  assign("mle.data", mle.data,pos=1) #
  assign("special.stuff", special.stuff,pos=1) #
                                        #
                                        #if this was a simulated set of data, use the simulation parameters 
                                        #
                                        #  this is not always a good idea; 
                                        #  sometimes with small samples, using data is much better
                                        #
  if(!is.null(mle.data$sim.parameters)) theta.start <- mle.data$
  sim.parameters #try to find mle
  if(is.null(em.alg)) {
                                        #
                                        # est.out <- list(x = minfun(log.like, theta.start)) 
                                        #d <- min(10000,1/max(.00001,abs(theta.start)))
    est.out <-nlminb(objective=log.like, start=theta.start,
                       control=(list(eval.max = max.fcal, iter.max = max.iter,
                                     rel.tol=rfc.tol)))
#nlm(log.like, theta.start, stepmax = max.fcal,iterlim = max.iter, steptol = rfc.tol, ...)
    
  }
  else {
    est.out <- em.alg(mle.data, theta.start)
  }
  if(dump > 19)
    browser()
  t.param <- est.out$par
  names(t.param) <- t.param.names #
                                        #
                                        #compute the maximum of the likelihood
                                        #
  max.log.like <- -(log.like(t.param)) #
                                        #
                                        #hessian and variance covariance matrix
                                        #
  grad <- my.gradient(log.like, t.param)
  hess <- my.hessian(log.like, t.param)
  dimnames(hess) <- list(t.param.names, t.param.names)
  eigen.hess <- eigen(hess)
  t.vcv <- solve(hess)
  t.standard.error <- sqrt(abs(diag(t.vcv)))
  names(t.param.names) <- t.param.names
  names(t.standard.error) <- t.param.names
  if(any(eigen.hess$values <= 0)) warning("Nonpositive eigenvalues") #
                                        #
                                        #return everything (including likelihood and data) in a list
                                        #
  gmle.out <- list(mle.data = mle.data, log.like = log.like, model = 
                   model, em.alg = em.alg, special.stuff = special.stuff, est.out
                   = est.out, max.log.like = max.log.like, grad = grad, hess = 
                   hess, eigen.hess = eigen.hess, t.vcv = t.vcv, t.param = t.param,
                   t.standard.error = t.standard.error) #
                                        #
                                        # go back to original parameters if function is non-identity
                                        #    we want to return that stuff too
                                        #
  if(!missing(f.origparam)) {
    genorigparm.out <- f.genorigparmvcv(t.vcv, t.param, f.origparam,
                                        model = model)
    origparam <- genorigparm.out$vec
    names(origparam) <- orig.param.names
    gmle.out$origparam <- origparam
    origparamvcv <- genorigparm.out$vcv
    dimnames(origparamvcv) <- list(orig.param.names, 
                                   orig.param.names)
    gmle.out$origparamvcv <- origparamvcv
  }
  gmle.out$func.call <- func.call
  gmle.out$date <- date()
  class(gmle.out) <- "gmle.out"
  return(gmle.out)
}

rfl0.mle.plot=function(out = panel22.out, theta = NULL, yrange = NULL, min.x = NULL, max.x = NULL, pts = 50.)
{
	par(mar = c(5.1, 6., 4.1, 2.1))
	if(is.null(theta))
		theta <- c(out$parameter$beta0, out$parameter$beta1, out$parameter$sigma, out$parameter$mugamma, out$parameter$sdgamma)
	data <- out$mle.data
	xval <- data$xmat
	xlab=data$xlab
	ylab=data$units
	if(is.null(min.x))
		min.x <- min(xval)
	if(is.null(max.x))
		max.x <- max(xval)
	yval <- data$y
	censor.codes <- data$censor.codes
	beta0 <- theta[1.]
	beta1 <- theta[2.]
	sigma <- theta[3.]
	mugamma <- theta[4.]
	sdgamma <- theta[5.]
	beta0.r <- beta0 + beta1 * mugamma
	beta1.r <- beta1/sigma
	ydist <- data$ydist
	fldist <- data$fldist
	if(fldist == 1.)
		fl.dist <- psev
	if(fldist == 2.)
		fl.dist <- pnorm
	if(fldist == 3.)
		fl.dist <- plogis
	incre <- (log(max.x) - log(min.x))/pts
	tot <- pts:0.
	x <- exp(log(min.x) + incre * (pts - tot))
	x.r <- (log(x) - mugamma)/sdgamma
	y.05 <- rep(NA, pts)
	y.5 <- rep(NA, pts)
	y.95 <- rep(NA, pts)
	for(i in 1.:(pts + 1.)) {
		if(i > 1.) {
			if(is.na(y.05[i - 1.]))
				limits <- log(range(yval))
			else limits <- c(0.7 * y.05[i - 1.], y.05[i - 1.])
		}
		else limits <- log(range(yval))
		check <- fl.dist(log(x[i]), mugamma, sdgamma)
		if(check > 0.05) {
			dummy <- find.rfl0.quan(0.05, ydist, fldist, beta1.r, sdgamma, x.r[i], bds = limits)
			if(dummy >= 499.)
				y.05[i] <- NA
			else y.05[i] <- beta0.r + sigma * dummy
		}
		if(check > 0.5) {
			dummy <- find.rfl0.quan(0.5, ydist, fldist, beta1.r, sdgamma, x.r[i], bds = c(y.05[i], 1.2 * y.05[i]))
			if(dummy >= 499.)
				y.5[i] <- NA
			else y.5[i] <- beta0.r + sigma * dummy
		}
		if(check > 0.95) {
			dummy <- find.rfl0.quan(0.95, ydist, fldist, beta1.r, sdgamma, x.r[i], bds = c(y.5[i], 1.2 * y.5[i]))
			if(dummy >= 499.)
				y.95[i] <- NA
			else y.95[i] <- beta0.r + sigma * dummy
		}
	}
	x.05 <- x[(!(is.na(y.05)))]
	y.05 <- exp(y.05[(!(is.na(y.05)))])
	x.5 <- x[(!(is.na(y.5)))]
	y.5 <- exp(y.5[(!(is.na(y.5)))])
	x.95 <- x[(!(is.na(y.95)))]
	y.95 <- exp(y.95[(!(is.na(y.95)))])
	if(is.null(yrange)) {
		ymax <- max(y.95, yval)
		ymin <- min(y.05, yval)
	}
	else {
		ymax <- yrange[2.]
		ymin <- yrange[1.]
	}
	stress <- c(min.x, max.x)
	cycles <- c(ymin, ymax)
	plot(stress, cycles, type = "n", log = "xy", xlab = xlab, ylab = ylab, cex = 1.1, axes = F)
	box()
	axis(1., at = pretty(x))
	ticks <- as.integer(exp(pretty(log(c(y.05,y.95)),nint=8)))
	axis(2., at = ticks[ticks <= ymax], mgp = c(3.25, 1.75, 0.), cex = 1.)
	lines(x.05[y.05 <= ymax], y.05[y.05 <= ymax], lty = 3.)
	lines(x.5[y.5 <= ymax], y.5[y.5 <= ymax], lty = 3.)
	lines(x.95[y.95 <= ymax], y.95[y.95 <= ymax], lty = 3.)
	points(xval[censor.codes == 1.], yval[censor.codes == 1.], cex = 1.)
	if(any(censor.codes == 2.)) {
		points(xval[censor.codes == 2.], yval[censor.codes == 2.], pch = 2., cex = 1.)
	}
	par(mar = c(5.1, 4.1, 4.1, 2.1))
	invisible()
}

psev=function(x,mu=0,sigma=1){
	z=(x-mu)/sigma
	1-exp(-exp(z))
}

find.rfl0.quan=function(alpha, ydist, fldist, beta1.r, sdgamma, x.r, bds)
{
	if(is.na(bds[1.]))
		bds <- c(-10., 10.)
	if(fldist == 1.)
		check <- psev(x.r, 0., 1)
	if(fldist == 2.)
    	check <- pnorm(x.r, 0., 1)
	if(fldist == 3.)
		check <- plogis(x.r, 0., 1)
	if(check > alpha) {
		quan <- rfl0quan(ydist, fldist, x.r, alpha, beta1.r, sdgamma, bds[1.], bds[2.])
		return(quan)
	}
	else {
		return(NA)
		print("The quantile is higher than proportion failing.")
		print(paste("alpha =", alpha))
		print(paste("propn failing =", check))
		stop()
	}
}

rflm.read.data <- 
function(data.file = "concrete.txt", dat.mat = NULL, title = "Concrete Data", xlab = "stress", units = "1000 cycles")
{
	if(!is.null(data.file))
		dat.mat <- matrix(scan(data.file), ncol = 3., byrow = T)
	y <- dat.mat[, 2.]
	x <- dat.mat[, 1.]
	log.y <- log(y)
	case <- 1.:length(y)
	for(i in 1.:length(y)) {
		case[i] <- paste("case", i)
	}
	y <- matrix(y, ncol = 1., dimnames = list(case, units))
	xmat <- matrix(x, ncol = 1., dimnames = list(case, xlab))
	log.y <- matrix(log.y, ncol = 1., dimnames = list(case, paste("log", units)))
	censor.codes <- dat.mat[, 3.]
	case.weights <- rep(1., length(y))
	return(list(title=title, units=units, y=y, censor.codes=censor.codes, case.weights=case.weights, log.y=log.y, xmat=xmat, xlab=xlab))
	invisible()
}

"expand.vec" <- 
function(a, nplan)
{
	if(length(a) == 1.) {
		a <- rep(a, length = nplan)
	}
	if(length(a) != nplan)
		stop(paste(deparse(substitute(a)), "has length", length(a), "for", nplan, "plans"))
	return(a)
}

"panel.d" <- 
list("title" = "Panel Data"
, "units" = "1000 cycles"
, "censor.codes" = c(1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 2., 2., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 2., 2., 2., 2., 2., 2., 2., 2.)
, "case.weights" = c(1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.)
, "log.y" = matrix(c(3.5322256440685602, 3.629660094453965, 3.7376696182833689, 3.7447870860522321, 3.8753590210565538, 3.9608131695975781, 
	4.0235643801610532, 4.0656020933564463, 4.1222839309113422, 4.169761201506855, 4.1743872698956368, 4.1820501426412058, 
	4.254193263163998, 4.2626798770413163, 4.282206299391671, 4.3201512309557941, 4.3489867805956823, 4.3541414311843463, 
	4.475061500641071, 4.536891345234797, 4.5432947822700038, 4.5767707114663931, 4.6011621645905523, 4.75960653929251, 
	4.808111029984782, 4.832305758571839, 5.0556086597389873, 5.15675380222625, 5.17558460116574, 5.1896179496246946, 
	5.2390980068880646, 5.2735122476290659, 5.338018733399589, 5.3561144652742536, 5.4120923808068806, 5.4205349992722862, 
	5.5333894887275203, 5.543222409643759, 5.5568280616995374, 5.6131281063880696, 5.6767538022682817, 5.7051149198899793, 
	5.7114199017854128, 5.7310733348921046, 6.0070918029936813, 6.0419199905964751, 6.0602907380378346, 6.4994862435412379, 
	6.6542813778600944, 6.6769575087310677, 6.8606636714482869, 6.8663080890679637, 7.0855666802982054, 7.1232698031318558, 
	7.1312187791072672, 7.1589030267059446, 7.2516995304420524, 7.309948373219882, 7.3256099847362242, 7.3425849957202054, 
	7.3469130280567709, 7.3689073485045551, 7.4019025896953146, 7.4287490316637532, 7.5632525120901777, 7.6065365581591742, 
	7.6833115957827998, 7.7796760631203519, 7.8514276875975106, 7.8916672754537682, 7.9799209176352628, 8.0217486696885487, 
	8.0409300119993574, 8.1671249465283609, 8.3690875368846402, 7.8648808052946269, 7.8673736635914704, 7.927829283319765, 
	8.0369614327348806, 8.3594159435332802, 8.6984808806198952, 8.7734619931622753, 8.9132811377118042, 9.0002364341697767, 
	9.0475390496681332, 9.0589010131938288, 9.0630461329454128, 9.0843235313926964, 9.0848111620278296, 9.1064676379111429, 
	9.2227431386932253, 9.2265778280658441, 9.3186565154596419, 9.4310650000530831, 9.4904614318790834, 9.5333944145084342, 
	9.6381147670041791, 9.6828845213660255, 9.9120656551859678, 9.9382319156131462, 8.5492924532762373, 8.5697666660233054, 
	8.9700252291536451, 9.010486009889922, 9.1578463570121134, 9.2273744645319624, 9.2867642318192356, 9.3549773684630146, 
	9.4060305031756819, 9.4965713921606483, 9.6713789348362678, 9.680112724479514, 9.7569982823490449, 9.8418248921440217, 
	9.8789130579695481, 9.8902249923025494, 9.9210572966461879, 9.9284094071412241, 9.9297545349118472, 9.9297545349118472, 
	9.9299395920365878, 9.9300418457573745, 9.9308594993319783, 9.9417173903191305, 9.9482840382917921)
, nrow = 125, ncol = 1)
, "xlab" = "Stress (MPa)"
, "y" = matrix(c(34.200000000000003, 37.700000000000003, 42., 42.299999999999997, 48.200000000000003, 52.5, 55.899999999999999, 58.299999999999997, 
	61.700000000000003, 64.700000000000003, 65., 65.5, 70.400000000000006, 71., 72.400000000000006, 75.200000000000003, 
	77.400000000000006, 77.799999999999997, 87.799999999999997, 93.400000000000006, 94., 97.200000000000003, 99.599999999999994, 116.7,
	122.5, 125.5, 156.90000000000001, 173.59999999999999, 176.90000000000001, 179.40000000000001, 188.5, 195.09999999999999, 
	208.09999999999999, 211.90000000000001, 224.09999999999999, 226., 253., 255.5, 259., 274., 292., 300.39999999999998, 
	302.30000000000001, 308.30000000000001, 406.30000000000001, 420.69999999999999, 428.5, 664.79999999999995, 776.10000000000002,
	793.89999999999998, 954., 959.39999999999998, 1194.5999999999999, 1240.5, 1250.4000000000001, 1285.5, 1410.5, 1495.0999999999999,
	1518.7, 1544.7, 1551.4000000000001, 1585.9000000000001, 1639.0999999999999, 1683.7, 1926.0999999999999, 2011.3, 2171.8000000000002,
	2391.5, 2569.4000000000001, 2674.9000000000001, 2921.6999999999998, 3046.5, 3105.5, 3523.1999999999998, 4311.6999999999998, 
	2604.1999999999998, 2610.6999999999998, 2773.4000000000001, 3093.1999999999998, 4270.1999999999998, 5993.8000000000002, 6460.5,
	7430., 8105., 8497.6000000000004, 8594.7000000000007, 8630.3999999999996, 8816., 8820.2999999999993, 9013.3999999999996, 
	10124.799999999999, 10163.700000000001, 11144., 12469.799999999999, 13232.9, 13813.4, 15338.4, 16040.700000000001, 
	20172.299999999999, 20707.099999999999, 5163.1000000000004, 5269.8999999999996, 7863.8000000000002, 8188.5, 9488.6000000000004,
	10171.799999999999, 10794.200000000001, 11556.200000000001, 12161.5, 13314., 15857.200000000001, 15996.299999999999, 
	17274.700000000001, 18804., 19514.5, 19736.5, 20354.5, 20504.700000000001, 20532.299999999999, 20532.299999999999, 
	20536.099999999999, 20538.200000000001, 20555., 20779.400000000001, 20916.299999999999)
, nrow = 125, ncol = 1
,  dimnames = list(c("case 1", "case 2", "case 3", "case 4", "case 5", "case 6", "case 7", "case 8", "case 9", "case 10", "case 11", "case 12", "case 13",
	"case 14", "case 15", "case 16", "case 17", "case 18", "case 19", "case 20", "case 21", "case 22", "case 23", "case 24", "case 25",
	"case 26", "case 27", "case 28", "case 29", "case 30", "case 31", "case 32", "case 33", "case 34", "case 35", "case 36", "case 37",
	"case 38", "case 39", "case 40", "case 41", "case 42", "case 43", "case 44", "case 45", "case 46", "case 47", "case 48", "case 49",
	"case 50", "case 51", "case 52", "case 53", "case 54", "case 55", "case 56", "case 57", "case 58", "case 59", "case 60", "case 61",
	"case 62", "case 63", "case 64", "case 65", "case 66", "case 67", "case 68", "case 69", "case 70", "case 71", "case 72", "case 73",
	"case 74", "case 75", "case 76", "case 77", "case 78", "case 79", "case 80", "case 81", "case 82", "case 83", "case 84", "case 85",
	"case 86", "case 87", "case 88", "case 89", "case 90", "case 91", "case 92", "case 93", "case 94", "case 95", "case 96", "case 97",
	"case 98", "case 99", "case 100", "case 101", "case 102", "case 103", "case 104", "case 105", "case 106", "case 107", "case 108",
	"case 109", "case 110", "case 111", "case 112", "case 113", "case 114", "case 115", "case 116", "case 117", "case 118", "case 119",
	"case 120", "case 121", "case 122", "case 123", "case 124", "case 125")
, "Cycles"
)
)
, "xmat" = matrix(c(380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380., 380.,
	380., 380., 380., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340., 340.,
	340., 340., 340., 340., 340., 340., 340., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300.,
	300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 300., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280.,
	280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 280., 270., 270., 270., 270., 270., 270.,
	270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270., 270.)
, nrow = 125, ncol = 1
,  dimnames = list(c("case 1", "case 2", "case 3", "case 4", "case 5", "case 6", "case 7", "case 8", "case 9", "case 10", "case 11", "case 12", "case 13",
	"case 14", "case 15", "case 16", "case 17", "case 18", "case 19", "case 20", "case 21", "case 22", "case 23", "case 24", "case 25",
	"case 26", "case 27", "case 28", "case 29", "case 30", "case 31", "case 32", "case 33", "case 34", "case 35", "case 36", "case 37",
	"case 38", "case 39", "case 40", "case 41", "case 42", "case 43", "case 44", "case 45", "case 46", "case 47", "case 48", "case 49",
	"case 50", "case 51", "case 52", "case 53", "case 54", "case 55", "case 56", "case 57", "case 58", "case 59", "case 60", "case 61",
	"case 62", "case 63", "case 64", "case 65", "case 66", "case 67", "case 68", "case 69", "case 70", "case 71", "case 72", "case 73",
	"case 74", "case 75", "case 76", "case 77", "case 78", "case 79", "case 80", "case 81", "case 82", "case 83", "case 84", "case 85",
	"case 86", "case 87", "case 88", "case 89", "case 90", "case 91", "case 92", "case 93", "case 94", "case 95", "case 96", "case 97",
	"case 98", "case 99", "case 100", "case 101", "case 102", "case 103", "case 104", "case 105", "case 106", "case 107", "case 108",
	"case 109", "case 110", "case 111", "case 112", "case 113", "case 114", "case 115", "case 116", "case 117", "case 118", "case 119",
	"case 120", "case 121", "case 122", "case 123", "case 124", "case 125")
, "Stress"
)
)
)

"inconel.d" <- 
list("title" = "Inconel 718 data"
, "units" = "1000 cycles"
, "y" = c(3143.4679999999998, 551.15999999999997, 1047., 1055.4000000000001, 1212.3, 2658.712, 5000., 2762.7049999999999, 3851.3789999999999,
	5175.6499999999996, 168.16999999999999, 188.99000000000001, 5229.933, 101.623, 134.75, 436.76100000000002, 70.091999999999999,
	108.02, 108.598, 108.598, 62.222999999999999, 64.951999999999998, 105.39, 113.48, 118.18000000000001, 202.30000000000001, 
	213.02000000000001, 213.02000000000001, 239.85400000000001, 74.260000000000005, 74.659999999999997, 87.373000000000005, 
	124.34999999999999, 181.93000000000001, 182.41, 68.143000000000001, 73.200000000000003, 100.03, 118.364, 119.54000000000001, 
	69.766000000000005, 81.138000000000005, 96.799000000000007, 72.120000000000005, 79.519999999999996, 86.420000000000002, 
	88.224999999999994, 91.560000000000002, 95.609999999999999, 111.90000000000001, 59.246000000000002, 64.013999999999996, 
	75.168999999999997, 88.069999999999993, 48.747999999999998, 48.747999999999998, 68.028999999999996, 68.028999999999996, 
	59.095999999999997, 105.66, 44.216000000000001, 45.375, 47.466999999999999, 25.893000000000001, 25.893000000000001, 
	44.325000000000003, 49.805999999999997, 85.471000000000004, 39.401000000000003, 41.944000000000003, 54.299999999999997, 
	54.299999999999997, 55.503, 65.510999999999996, 71.888000000000005, 72.894999999999996, 27.771999999999998, 27.771999999999998,
	52.799999999999997, 49.298000000000002, 49.298000000000002, 53.667999999999999, 53.667999999999999, 30.702000000000002, 
	30.702000000000002, 36.192999999999998, 36.192999999999998, 43.898000000000003, 43.898000000000003, 33.313000000000002, 
	40.539999999999999, 40.539999999999999, 71.424999999999997, 35.198, 32.100000000000001, 46.898000000000003, 63.116999999999997,
	70.951999999999998, 85.138000000000005, 43.128, 56.634, 29.289999999999999, 36.420000000000002, 34.590000000000003, 
	46.645000000000003, 30.297000000000001, 23.673999999999999, 27.454999999999998, 12.922000000000001, 12.922000000000001, 32.57,
	18.393999999999998, 27.780000000000001, 33.509999999999998, 27.765999999999998)
, "censor.codes" = c(2., 1., 1., 1., 1., 1., 2., 1., 1., 2., 1., 1., 2., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.)
, "case.weights" = c(1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.,
	1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1., 1.)
, "log.y" = c(8.0530819280353398, 6.3120251481257004, 6.9536842108705397, 6.9616751209715702, 7.1002746607525404, 7.8855970739816588, 8.51719319141624,
	7.9239655512175204, 8.2561865449682195, 8.5517202141107997, 5.1249753725346601, 5.2416941036069504, 8.5621537462694501, 
	4.6212698874775198, 4.9034212097891103, 6.0793861347301998, 4.2498086648461699, 4.6823163951647402, 4.6876529911239899, 
	4.6876529911239899, 4.13072470631485, 4.17364853556015, 4.6576677549458498, 4.7316266099406503, 4.7722088859175296, 
	5.3097517441736999, 5.3613860580150199, 5.3613860580150199, 5.4800304048988604, 4.30757244874893, 4.3129444734864402, 
	4.4701863104493702, 4.8231001702494103, 5.2036219977087104, 5.2062569006988202, 4.2216084382668901, 4.2931954209672698, 
	4.60547014099709, 4.7737646221620498, 4.7836510433961097, 4.2451467850764599, 4.3961514087192803, 4.5726366636506599, 
	4.2783313983351201, 4.3760085623483196, 4.45921913050379, 4.4798903695613301, 4.5169944950843703, 4.5602774170973603, 
	4.71760561531788, 4.0816982671877797, 4.1591018094373799, 4.31973891192143, 4.4781319528173702, 3.8866641709612599, 
	3.8866641709612599, 4.2199340848516096, 4.2199340848516096, 4.0791632402264399, 4.6602263917361704, 3.7890867145309599, 
	3.81496129258502, 3.8600347327570201, 3.2539726619056299, 3.2539726619056299, 3.79154885196027, 3.9081354587009498, 
	4.4481771371211796, 3.6737911966924601, 3.7363353952702298, 3.9945242269398902, 3.9945242269398902, 4.0164370733455801, 
	4.1822180674723404, 4.2751093523278003, 4.2890200495567798, 3.3240283188910298, 3.3240283188910298, 3.9665111907122199, 
	3.89788351227442, 3.89788351227442, 3.9828169207282298, 3.9828169207282298, 3.4243277990510101, 3.4243277990510101, 
	3.5888657299675599, 3.5888657299675599, 3.7818687609567601, 3.7818687609567601, 3.5059477111942901, 3.7022891410238499, 
	3.7022891410238499, 4.2686479481168398, 3.56098926280802, 3.4688560301359699, 3.8479750306197098, 4.14499014689099, 
	4.2620035920741497, 4.4442734694029298, 3.76417243814937, 4.0366095115708598, 3.3772461608396398, 3.5951180742994602, 
	3.5435646229490798, 3.8425657404129199, 3.4110486977125301, 3.1643773995317002, 3.3125483007308398, 2.5589312851359698, 
	2.5589312851359698, 3.48339161928814, 2.9120245244805099, 3.3243163373261999, 3.51184390174922, 3.32381225061261)
, "xmat" = c(3.6000000000000001, 3.7000000000000002, 3.7000000000000002, 3.7000000000000002, 3.7000000000000002, 3.7000000000000002, 
	3.7000000000000002, 3.8999999999999999, 3.8999999999999999, 3.8999999999999999, 4., 4., 4., 4.0999999999999996, 4.0999999999999996,
	4.0999999999999996, 4.2000000000000002, 4.2000000000000002, 4.2000000000000002, 4.2000000000000002, 4.2999999999999998, 
	4.2999999999999998, 4.2999999999999998, 4.2999999999999998, 4.2999999999999998, 4.2999999999999998, 4.2999999999999998, 
	4.2999999999999998, 4.2999999999999998, 4.4000000000000012, 4.4000000000000012, 4.4000000000000012, 4.4000000000000012, 
	4.4000000000000012, 4.4000000000000012, 4.5, 4.5, 4.5, 4.5, 4.5, 4.5999999999999996, 4.5999999999999996, 4.5999999999999996, 
	4.5999999999999996, 4.7000000000000002, 4.7000000000000002, 4.7000000000000002, 4.7999999999999998, 4.7999999999999998, 
	4.7999999999999998, 4.9000000000000012, 4.9000000000000012, 4.9000000000000012, 4.9000000000000012, 5., 5., 5., 5., 
	5.0999999999999996, 5.0999999999999996, 5.2000000000000002, 5.2000000000000002, 5.2000000000000002, 5.2999999999999998, 
	5.2999999999999998, 5.2999999999999998, 5.2999999999999998, 5.2999999999999998, 5.4000000000000012, 5.4000000000000012, 
	5.4000000000000012, 5.4000000000000012, 5.4000000000000012, 5.4000000000000012, 5.4000000000000012, 5.4000000000000012, 5.5, 5.5,
	5.5, 5.5999999999999996, 5.5999999999999996, 5.5999999999999996, 5.5999999999999996, 5.7000000000000002, 5.7000000000000002, 
	5.7000000000000002, 5.7000000000000002, 5.7000000000000002, 5.7000000000000002, 5.7999999999999998, 5.7999999999999998, 
	5.7999999999999998, 5.7999999999999998, 5.9000000000000012, 6., 6., 6., 6., 6., 6.0999999999999996, 6.0999999999999996, 
	6.2000000000000002, 6.2000000000000002, 6.2999999999999998, 6.2999999999999998, 6.4000000000000012, 6.5999999999999996, 
	6.5999999999999996, 6.7000000000000002, 6.7000000000000002, 6.7000000000000002, 6.7999999999999998, 6.7999999999999998, 
	6.7999999999999998, 7.)
, "xlab" = "1000*strain"
)

"ask.if" <- 
function(prompt = "Continue? ")
{
	if(!interactive() || (exists(".Batch") && .Batch))
		return(TRUE)
	repeat {
		cat(prompt)
		ans <- readline()
		invisible()
		if(ans == "y" | ans == "yes")
			return(TRUE)
		if(ans == "n" | ans == "no")
			return(FALSE)
		cat("Answer y or n\n")
	}
}

"ccor" <- 
function(vcv)
{
	if(length(vcv) == 1.) {
		return(1.)
	}
	else {
		diag(1./sqrt(abs(diag(vcv)))) %*% vcv %*% diag(1./sqrt(abs(diag(vcv))))
	}
}

"func.eval" <- 
function(theta.short)
{
	#
	#find the constrained mle
	#
	#theta.short is a subset of the theta vector to be used in
	#the profile x/y or x/y/z contour/likelihood plots
	#assume theta.start is on frame 1 and that the [-profile.on.pos]
	#elements contain
	#a reasonable start value for the
	#constrained optimization problem
	profile.on.pos <- #
	get("profile.on.pos", pos = 1.)
	#
	#put the fixed part in theta.start
	#and save it to allow constraining the mle
	#
	theta.start <- #
	get("theta.start", pos = 1.)
	theta.start[profile.on.pos] <- theta.short
	#pick up old part and pass down start value
	assign("theta.hold", value = theta.start, pos = 1.)
	#find the constrained mle
	theta.opt <- theta.start[-(profile.on.pos)]
	#	cmle <- list(x = minfun(const.log.like, theta.opt))	#
	#
	print(paste("Start values:", paste(theta.start, collapse = " ")))
	cmle <- nlminb(objective=const.log.like, start=theta.opt,control=(list(eval.max = 1000., iter.max = 900.)))
	theta.start[-(profile.on.pos)] <- cmle$par
	print(paste("Final values:", paste(theta.start, collapse = " ")))
	print(cmle)
	assign("theta.start", theta.start, pos = 1.)
	return(const.log.like(cmle$par))
}

"get.gradient.delta" <- 
function(f.fun, theta, i, f.of.theta, epsilon, ...)
{
	delta <- 0.001 * theta
	deltai <- delta[i] * diag(length(theta))[, i]
	y.want <- f.of.theta + epsilon
	return(lin.interpol(theta[i], theta[i] + delta[i], f.of.theta, f.fun(theta + deltai, ...), f.of.theta + epsilon) - theta[i])
}


"linax" <- 
function(xmax, xmin, nint = 5., nticks = 4.)
{
	if(missing(xmin) && length(xmax == 2.)) {
		xmin <- xmax[1.]
		xmax <- xmax[2.]
	}
	ticlab <- pretty(c(xmax, xmin), nint = nint)
	ticloc <- seq(ticlab[1.], ticlab[length(ticlab)], length = (length(ticlab) - 1.) * (nticks + 1.) + 1.)
	return(list(ticlab = format(ticlab), ticloc = format(ticloc)))
}

"mid.start" <- 
function(theta.hat, range, size)
{
	if(theta.hat <= range[1.])
		return(1.)
	if(theta.hat >= range[2.])
		return(2. * size + 1.)
	return(floor(((theta.hat - range[1.])/(range[2.] - range[1.])) * (2. * size) + 1.01))
}

"my.gradient" <- 
function(f.fun, theta, epsilon = rep(1.0000000000000001e-005, length(theta)), ...)
{
	xgrad <- rep(0., length(theta))
	f.of.theta <- f.fun(theta, ...)
	for(i in 1.:length(theta)) {
		deltai <- get.gradient.delta(f.fun, theta, i, f.of.theta, epsilon[i], ...) * diag(length(theta))[, i]
		xgrad[i] <- (f.fun(theta + deltai, ...) - f.fun(theta - deltai, ...))/(2. * deltai[i])
	}
	return(xgrad)
}

"my.hessian" <- 
function(f.fun, theta, delta = 0.001 * theta)
{
	hessian <- diag(length(theta))
	identity <- hessian
	fun.value <- f.fun(theta)
	for(i in 1.:length(theta)) {
		deltai <- delta[i] * identity[, i]
		for(j in 1.:i) {
			deltaj <- delta[j] * identity[, j]
			hessian[i, j] <- (f.fun(theta + deltai + deltaj) +  - f.fun(theta + deltaj - deltai) - f.fun(theta - deltaj + 
				deltai) + f.fun(theta - deltaj - deltai))/(4. * delta[i] * delta[j])
			hessian[j, i] <- hessian[i, j]
		}
	}
	return(hessian)
}

"pause" <- 
function(prompt = "Touch Return to continue; type stop to breakout: ")
{
	if(!interactive() || (exists(".Batch") && .Batch))
		return(TRUE)
	repeat {
		cat(prompt)
		ans <- readline()
		invisible()
		if(ans == "n" || ans == "no")
			return(TRUE)
		if(ans == "yes" || ans == "y")
			return(FALSE)
		if(ans == "")
			return(FALSE)
		if(ans == "stop")
			stop("Stopping")
	}
}

"rfl0quan" <- 
function(ydist = 2., fldist = 2., x.r = log(seq(60., 200., length = 10.)) - 3.7000000000000002, alpha = 0.050000000000000003, beta1.r = 
	-11.039999999999999
	, sdgamma = 0.83499999999999996, bd1 = -10., bd2 = 10.)
{
	max.length <- max(length(ydist), length(fldist), length(beta1.r), length(x.r), length(alpha))
	ydist <- expand.vec(ydist, max.length)
	fldist <- expand.vec(fldist, max.length)
	beta1.r <- expand.vec(beta1.r, max.length)
	sdgamma <- expand.vec(sdgamma, max.length)
	x.r <- expand.vec(x.r, max.length)
	alpha <- expand.vec(alpha, max.length)
	zout <- .Fortran("srfl0quan",
		as.integer(ydist),
		as.integer(fldist),
		as.double(x.r),
		as.double(alpha),
		as.double(beta1.r),
		as.double(sdgamma),
		as.double(bd1),
		as.double(bd2),
		as.integer(max.length),
		answer = double(max.length))
	return(zout$answer)
}

"lin.interpol" <- 
function(x1, x2, y1, y2, y.want)
{
	slope <- (x2 - x1)/(y2 - y1)
	return(x1 + slope * (y.want - y1))
}

"y.eval" <- 
function(gmle.out, profile.setup.out, x.range = NULL, profile.on, size = 10., dump = 1.)
{
                                        #
	#function to evaluate a one-dimensional profile likelihood
	#
	#put profile.on on frame 1 so that it is known below
	profile.on.pos <- profile.setup.out$profile.on.pos
	assign("profile.on.pos", value = profile.on.pos, pos = 1.)
	assign("profile.on", value = profile.on, pos = 1.)
	assign("model", value = gmle.out$model, pos = 1.)
	assign("dump", value = dump, pos = 1.)
	assign("log.like", value = gmle.out$log.like, pos=1.)
	assign("mle.data", value = gmle.out$mle.data, pos=1.)
	assign("special.stuff", value = gmle.out$special.stuff, pos=1.)
	h.theta.hat <- profile.setup.out$h.theta.hat
	assign("h.theta.hat", value = h.theta.hat, pos=1.)
	#
	log.scale <- gmle.out$max.log.like
	xvec <- seq(x.range[1.], x.range[2.], length = 2. * size + 1.)
	y <- rep(0., length(xvec))
	jmid.start <- mid.start(h.theta.hat[profile.on.pos], x.range, size)
	index.list <- profile.list(size, jmid.start)
	print(index.list)
	print(xvec)
	print(c(jmid.start, profile.on))
	for(j in index.list) {
		if(j == jmid.start)
			assign("theta.start", h.theta.hat, pos=1.)
		y[j] <- -(func.eval(xvec[j]))
	}
	return(list(x = xvec, y = exp(y - log.scale), xlab = profile.setup.out$profile.name, distribution = gmle.out$model$distribution,
		number.parameters = length(gmle.out$est.out$x), form = gmle.out$model$form, subtitle = gmle.out$mle.data$title))
}


"profile.list" <- 
function(size, imid = size + 1.)
return(c(imid:1., imid:(2. * size + 1.)))

"const.log.like" <- 
function(theta.opt)
{
	#
	#function to compute the constrained log likelihood
	#according to profile.on.pos, which must be of len 1 or 2
	#
	log.like <- get("log.like", pos=1.)
	theta.hold <- get("theta.hold", pos=1.)
	profile.on <- get("profile.on", pos=1.)
	profile.stable.parameters <- get("profile.stable.parameters", pos=1.)
	profile.on.pos <- get("profile.on.pos", pos=1.)
	theta <- theta.hold
	#
	theta[-(profile.on.pos)] <- theta.opt
	#print(paste("Theta in const.log.like=",theta))
	#
	theta.now <- profile.stable.parameters(theta, profile.on)
	return(log.like(theta.now))
}

"profile.plot" <- 
function(struct1, profile.title = paste(struct1$subtitle, "\n", lplot.type, "Likelihood and ", paste(as.integer(100. * confidence.level),
	"%", sep = ""), "Confidence Interval", "\n for", variable.name, model.dist.str), confidence.interval = T, confidence.level = 
	0.94999999999999996, x.range = NULL, y.range = c(0., 1.05), log.axis = F, variable.name = struct1$xlab, original.par = T, add = F,
	lty = 1., print.ci = T, col = 1., plotem = T)
{
	#plot structure from y.eval
	top.mar <- 7.
	cex.plot <- 1.2
	cex.lab <- 1.5
	cex.side3 <- 1.2
	cex.side4 <- 1.6000000000000001
	if(sum(par("mfrow")) != 2.) {
		top.mar <- 3.
		cex.plot <- 1.
		cex.lab <- 1.
		cex.side3 <- 1.
		cex.side4 <- 1.
	}
	old.par <- par(mar = c(6., 6., top.mar, 6.) + 0.10000000000000001, yaxs = "i")
	digits <- options(digits = 4.)
	#seems not to work
	on.exit(options(digits))
	if(original.par)
		on.exit(par(old.par))
	model.dist.str <- NULL
	if(!is.null(struct1$number.parameters) && struct1$number.parameters == 1.)
		lplot.type <- "Relative"
	else lplot.type <- "Profile"
	if(is.null(struct1$distribution)) {
		if(is.null(struct1$form)) {
			model.dist.str <- NULL
		}
		else {
			model.dist.str <- paste("from the", struct1$form, " Model")
		}
	}
	else {
		if(is.null(struct1$form)) {
			model.dist.str <- paste("from the", struct1$distribution, "Distribution")
		}
		else {
			model.dist.str <- paste("from the", struct1$distribution, struct1$form, " Model")
		}
	}
	if(!add) {
		frame()
		if(is.null(x.range))
			x.range <- range(struct1$x)
		if(log.axis)
			data.axes.out <- logax(x.range[1.], x.range[2.])
		else data.axes.out <- linax(x.range[1.], x.range[2.])
		#
		#set up patameter axes
		#
		#
		#
		plot(pp.data(x.range, log.axis), y.range, type = "n", xaxt = "n", xlab = "", ylab = "", cex = cex.plot, las = 1.)
		data.tick.location <- as.numeric(data.axes.out[[1]])
		data.tick.label.loc <- as.numeric(data.axes.out[[2]])
		axis(side = 1., at = pp.data(data.tick.location, log.axis), labels = F, tck = -0.01, mgp = c(5., 2.1000000000000001, 0.),
			cex = 1.)
		axis(side = 1., at = pp.data(data.tick.label.loc, log.axis), labels = data.axes.out[[2]], adj = 0.5, tck = -0.02, mgp = 
			c(5., 1.6000000000000001, 0.), cex = cex.plot)
		title(ylab = paste(lplot.type, "Likelihood"), cex = cex.lab)
		if(names(dev.cur()) == "postscript" && substring(variable.name, 1., 1.) == "~") {
			mixed.mtext(side = 1., line = 2.7999999999999998, texts = variable.name, adj = 0.5, cex = 1. * cex.lab)
		}
		else {
			title(xlab = variable.name, cex = cex.lab)
		}
		mtext(profile.title, side = 3., outer = F, line = 4., cex = cex.side3)
		abline(h = 0.)
		mtext("Confidence Level", side = 4., outer = F, line = 4., cex = cex.side4)
		if(confidence.interval) {
			axis.probs <- c(0.5, 0.59999999999999998, 0.69999999999999996, 0.80000000000000004, 0.90000000000000002, 
				0.94999999999999996, 0.98999999999999999)
			axis(side = 4., at = exp(-(qchisq(axis.probs, 1.))/2.), labels = paste("     ", format(axis.probs)))
		}
	}
	if(confidence.interval && plotem) {
		usr.out <- par("usr")
		hvalue <- exp(-(qchisq(confidence.level, 1.))/2.)
		abline(h = hvalue)
		ci <- ci.from.profile(struct1, confidence.level)
		if(print.ci)
			print(ci)
		ci <- pp.data(ci, log.axis)
		if(!is.na(ci[1.]))
			plot.line(c(ci[1.], usr.out[3.]), c(ci[1.], hvalue), lty = lty, col = col)
		if(!is.na(ci[2.]))
			plot.line(c(ci[2.], usr.out[3.]), c(ci[2.], hvalue), lty = lty, col = col)
	}
	if(plotem)
		lines(pp.data(struct1$x, log.axis), struct1$y, type = "l", lty = lty, col = col)
	invisible()
}

"pp.data" <- 
function(data.vector, log.of.data)
{
	if(log.of.data)
		return(log(data.vector))
	else return(data.vector)
}

"ci.from.profile" <- 
function(struct1, confidence.level = 0.94999999999999996)
{
	hvalue <- exp(-(qchisq(confidence.level, 1.))/2.)
	ci <- c(NA, NA)
	struct1.y <- struct1$y
	struct1.x <- struct1$x
	length.vec <- length(struct1.y)
	max.index <- is.max(struct1.y)
	if(struct1.y[1.] < hvalue) {
		item <- length(struct1.y[struct1.y < hvalue & diff(c(struct1.y, 0.)) > 0.])
		ci[1.] <- interpolate(struct1.y, struct1.x, item, hvalue)
	}
	if(struct1.y[length.vec] < hvalue) {
		item <- length(struct1.y[struct1.y < hvalue & diff(c(0., struct1.y)) < 0.])
		ci[2.] <- interpolate(struct1.y, struct1.x, length.vec - item, hvalue)
	}
	return(ci)
}

"is.max" <- 
function(x)
x == max(x)

"plot.line" <- 
function(point1, point2, xrange = NULL, col = 1., lty = 1., lwd = 1.)
{
	#print(paste("from",paste(point1,collapse=" "), 
	#	    "to",paste(point2,collapse=" ")))
	if(point1[1.] - point2[1.] != 0.) {
		slope <- (point1[2.] - point2[2.])/(point1[1.] - point2[1.])
		intercept <- point1[2.] - slope * point1[1.]
		if(is.null(xrange))
			xrange <- c(point1[1.], point2[1.])
		yrange <- intercept + slope * xrange
		lines(xrange, yrange, col = col, lty = lty, lwd = lwd)
	}
	else {
		lines(c(point1[1.], point2[1.]), c(point1[2.], point2[2.]), col = col, lty = lty, lwd = lwd)
	}
}




"interpolate" <- 
function(x, y, mark, xtarget)
{
	return(y[mark] + ((y[mark + 1.] - y[mark]) * (xtarget - x[mark]))/(x[mark + 1.] - x[mark]))
}


rev.rfl0.mle.plot=function(out = panel22.out, theta = NULL, yrange = NULL, min.x = NULL, max.x = NULL, pts = 100.,
           quan.vec=c(.01,.50,.99),adjust=0)
{
  par(mar = c(5.1, 6., 4.1, 2.1))
  quan.vec=sort(quan.vec)
  if(is.null(theta))
    theta <- c(out$parameter$beta0, out$parameter$beta1, out$parameter$sigma, out$parameter$mugamma, 
               out$parameter$sdgamma)
  data <- out$mle.data
  xval <- data$xmat
  xlab=data$xlab
  ylab=data$units
  if(is.null(min.x))
    min.x <- min(xval)
  if(is.null(max.x))
    max.x <- max(xval)
  yval <- data$y
  censor.codes <- data$censor.codes
  beta0 <- theta[1.]
  beta1 <- theta[2.]
  sigma <- theta[3.]
  mugamma <- theta[4.]
  sdgamma <- theta[5.]
  beta0.r <- beta0 + beta1 * mugamma
  beta1.r <- beta1/sigma
  ydist <- data$ydist
  fldist <- data$fldist
  if(fldist == 1.)
    fl.dist <- psev
  if(fldist == 2.)
    fl.dist <- pnorm
  if(fldist == 3.)
    fl.dist <- plogis
  incre <- (log(max.x) - log(min.x))/(pts-1)
  tot <- pts:1.
  x <- exp(log(min.x) + incre * (pts - tot))
  x.r <- (log(x) - mugamma)/sdgamma
  nq=length(quan.vec)  
  y.mat=matrix(NA,nrow=pts,ncol=nq)
  limits=log(range(yval))
  for(j in 1:nq){
    quan=quan.vec[j]
    for(i in 1.:pts) {
      check <- fl.dist(log(x[i]), mugamma, sdgamma)
      if(check > quan) {
        dummy <- find.rfl0.quan(quan, ydist, fldist, beta1.r, sdgamma, x.r[i], bds = limits)
        if(dummy < 499.)
          y.mat[i,j] <- exp(beta0.r + sigma * dummy)
      }
    }
  }
  if(is.null(yrange)) {
    ymax <- max(y.mat, yval,na.rm=T)
    ymin <- min(y.mat, yval,na.rm=T)
  }
  else {
    ymax <- yrange[2.]
    ymin <- yrange[1.]
  }
  adj.max.x=exp(log(max.x)+adjust*log(max.x/min.x))
  stress <- c(min.x,adj.max.x)
  cycles <- c(ymin, ymax)
  plot(cycles, stress, type = "n", log = "xy", xlab = ylab, ylab = xlab, cex = 1.1, axes = F)
  box()
  ticks <- as.integer(exp(pretty(log(y.mat),nint=8)))
  axis(1., at = ticks[ticks <= ymax])
  axis(2., at = pretty(x),mgp = c(3.25, 1.75, 0.))
  for(j in 1:nq){
    which=(!(is.na(y.mat[,j]))) & (y.mat[,j] <= ymax)
    lines(y.mat[which,j],x[which], lty = 3.)
    text(y.mat[pts,j],adj.max.x,quan.vec[j],cex=.80)
  }
  points(yval[censor.codes == 1.],xval[censor.codes == 1.])
  if(any(censor.codes == 2.)) {
    points(yval[censor.codes == 2.],xval[censor.codes == 2.],  pch = 15.)
  }
  par(mar = c(5.1, 4.1, 4.1, 2.1))
  quan.mat=matrix(ncol=length(quan.vec)+1,nrow=pts,dimnames=list(NULL,
                                    c("stress x",quan.vec)))
  quan.mat[,1]=x
  quan.mat[,2:(length(quan.vec)+1)]=y.mat
  return(quan.mat)
}

one.dim=function(gmle.out, profile.setup = NULL, profile.stable.parameters = NULL, profile.on.list = 1.:length(theta.hat), special.stuff.profile
	 = NULL, range.list = NULL, size = 40., interactive = T, dump = 0.,conf.level=.95)
{
	#
	#one-d profile likelihoods
	#
	#temp stop audit
	#
	old.options <- options()
	options(keep = NULL, digits = 5.)
	# assign.gmle(gmle.out, dump)
	on.exit(options(old.options))
	assign("special.stuff.profile", value = special.stuff.profile, pos=1.)
	theta.hat <- gmle.out$est.out$par
	if(is.null(profile.stable.parameters)) {
		if(any(profile.on.list > length(theta.hat)))
			stop("Need profile.stable.parameters function")
		profile.stable.parameters <- function(x.theta.hat, profile.on)
		{
			theta.hat <- x.theta.hat
			return(theta.hat)
		}
	}
	if(is.null(profile.setup)) {
		if(any(profile.on.list > length(theta.hat)))
			stop("Need profile.setup function")
		profile.setup <- function(theta.hat, t.profile.names, profile.on)
		{
			return(list(profile.name = t.profile.names[profile.on], h.theta.hat = theta.hat, profile.on.pos = profile.on,
				ktran = rep(1., length(profile.on))))
		}
	}
	assign("profile.stable.parameters", value = profile.stable.parameters, pos=1.)
	t.param.names <- gmle.out$model$t.param.names
	for(profile.index in 1.:length(profile.on.list)) {
		#get the default limits for the 1d plots if nothing specified in call
		profile.on <- profile.on.list[profile.index]
		if(is.null(range.list[[profile.index]])) {
			x.range <- profile.range(gmle.out, profile.on, profile.setup)
		}
		else {
			x.range <- range.list[[profile.index]]
		}
		profile.setup.out <- profile.setup(theta.hat, t.param.names, profile.on)
		print(profile.setup.out)
		profile.name <- profile.setup.out$profile.name
		if(!interactive || ask.if(paste("Profile likelihood plot on", profile.name, "? "))) {
			#browser()
			structx1 <- y.eval(gmle.out, profile.setup.out, x.range, profile.on = profile.on, size = size)
			print(structx1)
			assign(paste("struct", profile.on, sep = "", collapse = ""), structx1, pos = 1.)
			profile.plot(structx1,confidence.level=conf.level)
		}
	}
	invisible()
}


draw.profile.quan.1=function(output=panel22.out,ydist=2,fldist=2,stress=260,alpha=.01,quan.range=c(3000,9000),
								size=3,one.sided.level=.99)
{
	conf.level=1-2*(1-one.sided.level)
	xmat=output$mle.data$xmat
	mean.lx=mean(log(xmat))
	one.dim(output, profile.on.list = 6, special.stuff.profile = list(ydist = ydist, fldist = fldist, 
		alpha = alpha, stress=stress,mean.lx=mean.lx,low3rd=log(sort(xmat)[1:as.integer(length(xmat)/3)])),
		size= size, profile.setup = conv.2.fcn, profile.stable.parameters = conv.2.params, 
		range.list = list(quan.range),conf.level=conf.level)
	invisible()
} 


beta0.2.quan=function(ydist, fldist, alpha, bds, beta0, beta1, stress, sigma, mugamma, sdgamma)
{
	bd1 <- bds[1.]
	bd2 <- bds[2.]
	beta0.r=beta0+beta1*mugamma
	beta1.r=beta1/sigma
	x.r=(log(stress)-mugamma)/sdgamma
	quan = rfl0quan(ydist,fldist,x.r,alpha,beta1.r, sdgamma, bd1,bd2) 
	quan=exp(beta0.r + sigma*quan) 
	return(quan)
}

quan.2.beta0=function(ydist, fldist, alpha, quan, bds, beta1, stress, sigma, mugamma, sdgamma)
{
	bd1 <- bds[1.]
	bd2 <- bds[2.]
	zout <- .Fortran("sq2b",
		as.integer(ydist),
		as.integer(fldist),
		as.double(stress),
		as.double(alpha),
		as.double(quan),
		as.double(beta1),
		as.double(sigma),
		as.double(mugamma),
		as.double(sdgamma),
		as.double(bd1),
		as.double(bd2),
		beta0 = double(1.))
	return(zout$beta0)
}

"conv.2.params" <- 
function(x.theta.hat, profile.on)
{
	#
	# function to set up for special profile evaluations
	# needs to be the inverse of conv.2.fcn
	#
	theta.hat <- x.theta.hat
	if(!any(unlist(profile.on) > length(theta.hat)))
		return(theta.hat)
	switch(paste(profile.on, collapse = " "),
        #
        # 8 = beta0
	# 6 = quantile
	# 7 = stress to yield quantile
	#
		"8" = {
			beta0 <- theta.hat[1.]
			beta1 <- theta.hat[2.]
			sigma <- exp(theta.hat[3.])
			mugamma <- theta.hat[4.]
			sdgamma <- exp(theta.hat[5.])
			ydist <- get("special.stuff.profile", pos = 1.)$
				ydist
			fldist <- get("special.stuff.profile", pos = 1.)$
				fldist
			mean.lx <- get("special.stuff.profile", pos = 1.)$
				mean.lx
			theta.hat[1.] <- beta0 + beta1 * mean.lx
		}
		,
		"6" = {
			quan <- theta.hat[1.]
			beta1 <- theta.hat[2.]
			sigma <- exp(theta.hat[3.])
			sdgamma <- exp(theta.hat[5.])
			ydist <- get("special.stuff.profile", pos = 1.)$
				ydist
			fldist <- get("special.stuff.profile", pos = 1.)$
				fldist
			alpha <- get("special.stuff.profile", pos = 1.)$
				alpha
			stress <- get("special.stuff.profile", pos = 1.)$
				stress
			mean.lx <- get("special.stuff.profile", pos = 1.)$
				mean.lx
			low3rd <- get("special.stuff.profile", pos = 1.)$
				low3rd
                        mugamma=mean(low3rd) - sdgamma * theta.hat[4.]
			beta0 <- quan.2.beta0(ydist = ydist, fldist = fldist,
				alpha = alpha, quan = quan, bds = c(10., 60.),
				beta1 = beta1, stress = stress, sigma = sigma,
				mugamma = mugamma, sdgamma = sdgamma)
			theta.hat[1.] <- beta0 + beta1 * mean.lx
		}
		,
		"7" = {
			stress <- theta.hat[1.]
			beta1 <- theta.hat[2.]
			sigma <- exp(theta.hat[3.])
			low3rd <- get("special.stuff.profile", pos = 1.)$
				low3rd
		   mugamma=mean(low3rd) - sdgamma * theta.hat[4.]
			sdgamma <- exp(theta.hat[5.])
			ydist <- get("special.stuff.profile", pos = 1.)$
				ydist
			fldist <- get("special.stuff.profile", pos = 1.)$
				fldist
			alpha <- get("special.stuff.profile", pos = 1.)$
				alpha
			quan <- get("special.stuff.profile", pos = 1.)$
				quan
			mean.lx <- get("special.stuff.profile", pos = 1.)$
				mean.lx
			beta0 <- quan.2.beta0(ydist = ydist, fldist = fldist,
				alpha = alpha, quan = quan, bds = c(10., 60.),
				beta1 = beta1, stress = stress, sigma = sigma,
				mugamma = mugamma, sdgamma = sdgamma)
			theta.hat[1.] <- beta0 + beta1 * mean.lx
		}
		)
	return(theta.hat)
}

"conv.2.fcn" <- 
function(theta.hat, t.param.names, profile.on)
{
	#
	# function to set up for special profile evaluations and compute the
	# functions of the stable parameters that are really of interest
	#
	# fix parameters of interest
	#
	#
	#default
	#get the actual parameters for transformation below
	#
	h.theta.hat <- theta.hat
	beta0.t <- theta.hat[1.]
	beta1 <- theta.hat[2.]
	sigma <- exp(theta.hat[3.])
	low3rd <- get("special.stuff.profile", pos = 1.)$
				low3rd
	sdgamma <- exp(theta.hat[5.])
        mugamma=mean(low3rd) - sdgamma * theta.hat[4.]
	if(!any(unlist(profile.on) > length(theta.hat))) {
		profile.name <- t.param.names[profile.on]
		profile.on.pos <- profile.on
	}
	else {
		switch(paste(profile.on, collapse = " "),
          # 8 = beta0 
 			# 6 = quantile of interest
			# 7 = stress level to yield given quantile
			#
			"8" = {
				ydist <- get("special.stuff.profile", pos
					 = 1.)$ydist
				fldist <- get("special.stuff.profile", pos
					 = 1.)$fldist
				mean.lx <- get("special.stuff.profile", pos
					 = 1.)$mean.lx
				profile.on.pos <- 1.
				profile.name <- "beta0"
				h.theta.hat[1.] <- beta0.t - beta1 * mean.lx
			}
			,
			"6" = {
				ydist <- get("special.stuff.profile", pos
					 = 1.)$ydist
				fldist <- get("special.stuff.profile", pos
					 = 1.)$fldist
				alpha <- get("special.stuff.profile", pos = 
					1.)$alpha
				stress <- get("special.stuff.profile", pos
					 = 1.)$stress
				mean.lx <- get("special.stuff.profile", pos
					 = 1.)$mean.lx
				profile.on.pos <- 1.
				profile.name <- paste(alpha, 
					"Quantile at Stress =", stress)
				beta0 <- beta0.t - beta1 * mean.lx
				h.theta.hat[1.] <- beta0.2.quan(ydist = 
					ydist, fldist = fldist, alpha = alpha,
					bds = c(6., 10.), beta0 = beta0, beta1
					 = beta1, stress = stress, sigma = 
					sigma, mugamma = mugamma, sdgamma = 
					sdgamma)
			}
			,
			"7" = {
				ydist <- get("special.stuff.profile", pos
					 = 1.)$ydist
				fldist <- get("special.stuff.profile", pos
					 = 1.)$fldist
				alpha <- get("special.stuff.profile", pos = 
					1.)$alpha
				quan <- get("special.stuff.profile", pos = 
					1.)$quan
				mean.lx <- get("special.stuff.profile", pos
					 = 1.)$mean.lx
				profile.on.pos <- 1.
				profile.name <- paste("Stress Level: ", quan,
					"(log cycles) =", alpha, "Quantile")
				beta0 <- beta0.t - beta1 * mean.lx
				h.theta.hat[1.] <- quan.2.stress(ydist = 
					ydist, fldist = fldist, alpha = alpha,
					quan = quan, bds = c(270., 380.),
					beta0 = beta0, beta1 = beta1, sigma = 
					sigma, mugamma = mugamma, sdgamma = 
					sdgamma)
			}
			)
	}
	return(list(profile.name = profile.name, h.theta.hat = h.theta.hat,
		profile.on.pos = profile.on.pos))
}
